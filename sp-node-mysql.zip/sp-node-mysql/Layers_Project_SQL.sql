-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema Layers_Project
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Layers_Project
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `Layers_Project`;
CREATE SCHEMA IF NOT EXISTS `Layers_Project` DEFAULT CHARACTER SET latin1 ;
USE `Layers_Project` ;

-- -----------------------------------------------------
-- Table `Layers_Project`.`Hashtag`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Layers_Project`.`Hashtag`;
CREATE TABLE `Layers_Project`.`Hashtag` (
  `Hashtag` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Hashtag`),
  UNIQUE INDEX `Hashtag_UNIQUE` (`Hashtag` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `Layers_Project`.`User`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Layers_Project`.`User`;
CREATE TABLE `Layers_Project`.`User` (
  `UserID` INT(11) NOT NULL AUTO_INCREMENT,
  `Username` VARCHAR(45) NOT NULL UNIQUE,
  `User_Password` VARCHAR(20) NOT NULL,
  `First_Name` VARCHAR(45) NOT NULL,
  `Last_Name` VARCHAR(60) NOT NULL,
  `Date_of_Birth` DATE NOT NULL,
  PRIMARY KEY (`UserID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `Layers_Project`.`Layer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Layers_Project`.`Layer`;
CREATE TABLE `Layers_Project`.`Layer` (
  `LayerID` INT(11) NOT NULL AUTO_INCREMENT,
  `LayerName` VARCHAR(45) NOT NULL,
  `Length_of_Layer` INT(11) NOT NULL COMMENT 'Time in seconds',
  `Created_Date` DATETIME NOT NULL,
  `FileLayer` VARCHAR(45) NOT NULL COMMENT 'Represents relative path to file',
  `UserID` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`LayerID`),
  INDEX `UserID_idx` (`UserID` ASC),
  CONSTRAINT `UserID`
    FOREIGN KEY (`UserID`)
    REFERENCES `Layers_Project`.`User` (`UserID`)
    ON DELETE SET NULL
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `Layers_Project`.`Hashtag_Layer`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Layers_Project`.`Hashtag_Layer`;
CREATE TABLE `Layers_Project`.`Hashtag_Layer` (
  `Hashtag` VARCHAR(45) NOT NULL,
  `LayerID` INT(11) NOT NULL,
  PRIMARY KEY (`Hashtag`, `LayerID`),
  INDEX `LayerID_idx` (`LayerID` ASC),
  CONSTRAINT `Hashtag`
    FOREIGN KEY (`Hashtag`)
    REFERENCES `Layers_Project`.`Hashtag` (`Hashtag`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `LayerID`
    FOREIGN KEY (`LayerID`)
    REFERENCES `Layers_Project`.`Layer` (`LayerID`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `Layers_Project`.`Layer_Junction`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Layers_Project`.`Layer_Junction`;
CREATE TABLE `Layers_Project`.`Layer_Junction` (
  `BaseLayerID` INT(11) NOT NULL,
  `LinkedLayerID` INT(11) NOT NULL,
  PRIMARY KEY (`BaseLayerID`, `LinkedLayerID`),
  INDEX `LinkedLayerID_idx` (`LinkedLayerID` ASC),
  CONSTRAINT `BaseLayerID`
    FOREIGN KEY (`BaseLayerID`)
    REFERENCES `Layers_Project`.`Layer` (`LayerID`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `LinkedLayerID`
    FOREIGN KEY (`LinkedLayerID`)
    REFERENCES `Layers_Project`.`Layer` (`LayerID`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

use Layers_Project;

/* TRIGGERS TO ENSURE DATA INTEGRITY --------------------------------------- */

/* Trigger to automatically insert date as today */
DROP TRIGGER IF EXISTS `Created_Date_As_Today`;
DELIMITER ;;
CREATE TRIGGER `Created_Date_As_Today` BEFORE INSERT ON `Layer` FOR EACH ROW
BEGIN
    SET NEW.Created_Date = NOW();
END;;
DELIMITER ;

/* Trigger to check that length of layer is greater than 0 */
DROP TRIGGER IF EXISTS `Layer_Length_>0`;
DELIMITER ;;
CREATE TRIGGER `Layer_Length_>0` BEFORE INSERT ON `Layer` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* length of layer cannot be negative */
    IF (NEW.Length_of_Layer <= 0) THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 1) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Length of Layer must be greater than 0';
	END IF;
END;;
DELIMITER ;

/* Trigger to check that the file being uploaded is an mp3 */
DROP TRIGGER IF EXISTS `File_mp3`;
DELIMITER ;;
CREATE TRIGGER `File_mp3` BEFORE INSERT ON `Layer` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* file must end in .mp3 */
    IF (NEW.FileLayer LIKE '%.mp3') THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 0) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'File must be in ".mp3" format';
	END IF;
END;;
DELIMITER ;

/* Trigger to check that the hashtag has an # at the front */
DROP TRIGGER IF EXISTS `Hashtag_at_front`;
DELIMITER ;;
CREATE TRIGGER `Hashtag_at_front` BEFORE INSERT ON `Hashtag` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* hashtag has to start with a # */
    IF (NEW.Hashtag LIKE '#%') THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 0) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Hashtag must start with an #';
	END IF;
END;;
DELIMITER ;

/* Trigger to check that the hashtag has no spaces */
DROP TRIGGER IF EXISTS `Hashtag_no_spaces`;
DELIMITER ;;
CREATE TRIGGER `Hashtag_no_spaces` BEFORE INSERT ON `Hashtag` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* hashtag cannot have spaces */
    IF (NEW.Hashtag LIKE '% %') THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 1) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Hashtag cannot contains spaces';
	END IF;
END;;
DELIMITER ;


/* Trigger to check that the username has no spaces */
DROP TRIGGER IF EXISTS `Username_no_spaces`;
DELIMITER ;;
CREATE TRIGGER `Username_no_spaces` BEFORE INSERT ON `User` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* username cannot have spaces */
    IF (NEW.Username LIKE '% %') THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 1) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Username cannot contains spaces';
	END IF;
END;;
DELIMITER ;

/* Trigger to check that the username has no spaces */
DROP TRIGGER IF EXISTS `Password_no_spaces`;
DELIMITER ;;
CREATE TRIGGER `Password_no_spaces` BEFORE INSERT ON `User` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* username cannot have spaces */
    IF (NEW.User_Password LIKE '% %') THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 1) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Password cannot contains spaces';
	END IF;
END;;
DELIMITER ;

/* Trigger to check that the password has a minimum of 5 characters */
DROP TRIGGER IF EXISTS `Password_5_chars`;
DELIMITER ;;
CREATE TRIGGER `Password_5_chars` BEFORE INSERT ON `User` FOR EACH ROW
BEGIN
	DECLARE baddata INT;
    DECLARE specialty CONDITION FOR SQLSTATE '45000';
    SET baddata = 0;
    /* password has to be greater than or = to 5 chars*/
    IF (CHAR_LENGTH(NEW.User_Password) < 5) THEN
		SET baddata = 1;
	END IF;
	IF (baddata = 1) THEN
		SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'Password must be greater than or equal to 5 characters';
	END IF;
END;;
DELIMITER ;

/* EXAMPLE DATA FOR TABLES --------------------------------------- */

/*Hashtag Examples */
INSERT INTO Hashtag (Hashtag)
VALUES ("#socool");

INSERT INTO Hashtag (Hashtag)
VALUES ("#awesome");

INSERT INTO Hashtag (Hashtag)
VALUES ("#favoritesongever");


/*User Examples */
INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("samsmith", "happy12", "Sam", "Smith", '1992-7-04');

INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("emilyplatt", "yay120", "Emily", "Platt", '1995-8-29');

INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("caseysamuels", "woohoo", "Casey", "Samuels", '1991-10-18');

INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("lilybilly", "yikes", "Lily", "Bills", '1992-8-07');

INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("tammywilliams", "happyhappy", "Tammy", "Williams", '1939-1-13');


/* Layer Examples */
INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer, UserID)
VALUES ("Sorry_Beat", 60, "sorrybeat.mp3", 1);

INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer, UserID)
VALUES ("Dreamer Drums", 105, "dreamerdrums.mp3", 2);

INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer, UserID)
VALUES ("Dance Beat", 50, "dancebeat.mp3", 5);

INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer, UserID)
VALUES ("Classical Violin", 170, "classicalviolin.mp3", 3);

INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer, UserID)
VALUES ("Blues Base", 30, "bluesbase.mp3", 3);


/* Layer Junction Examples */
INSERT INTO Layer_Junction (BaseLayerID, LinkedLayerID)
VALUES (1, 2);

INSERT INTO Layer_Junction (BaseLayerID, LinkedLayerID)
VALUES (2, 3);

INSERT INTO Layer_Junction (BaseLayerID, LinkedLayerID)
VALUES (2, 4);

INSERT INTO Layer_Junction (BaseLayerID, LinkedLayerID)
VALUES (2, 5);

INSERT INTO Layer_Junction (BaseLayerID, LinkedLayerID)
VALUES (3, 5);


/* Hashtag_Layer Examples */
INSERT INTO Hashtag_Layer (Hashtag, LayerID)
VALUES ("#socool", 2);

INSERT INTO Hashtag_Layer (Hashtag, LayerID)
VALUES ("#awesome", 4);

INSERT INTO Hashtag_Layer (Hashtag, LayerID)
VALUES ("#awesome", 2);

INSERT INTO Hashtag_Layer (Hashtag, LayerID)
VALUES ("#socool", 5);



/* TESTS THAT TRIGGERS WORK --------------------------------------------------- */

/* TEST that trigger error for usernames do not contain spaces works */
INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("sam smith", "happy12", "Sam", "Smith", '1992-7-04');

/* TEST that trigger error for passwords do not contain spaces works */
INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("samsmith", "happy 12", "Sam", "Smith", '1992-7-04');

/* TEST that trigger error for passwords are at least 5 chars works */
INSERT INTO User (Username, User_Password, First_Name, Last_Name, Date_of_Birth)
VALUES ("samsmith", "hap", "Sam", "Smith", '1992-7-04');

/* TEST that trigger error for hashtags start with # works */
INSERT INTO Hashtag (Hashtag)
VALUES ("socool");

/* TEST that trigger error for hashtags do not contain spaces works */
INSERT INTO Hashtag (Hashtag)
VALUES ("#so cool");

/* TEST that trigger error for file that is not an mp3 */
INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer)
VALUES ("Blues Base", 30, "bluesbase.mp4");

/* TEST that trigger error for negative layer length works */
INSERT INTO Layer (LayerName, Length_of_Layer, FileLayer)
VALUES ("Sorry_Beat", -60, "sorrybeat.mp3");