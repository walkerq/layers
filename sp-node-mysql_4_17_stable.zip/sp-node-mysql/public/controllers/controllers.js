var myAppControllers = angular.module('myAppControllers', []);

/*myAppControllers.controller('ListCtrl', ['$scope', '$http',
  function ($scope, $http) {
    $http.get('phones/phones.json').success(function(data) {
      $scope.phones = data;
    });

    $scope.orderProp = 'age';
  }]);
*/

myAppControllers.controller('LayerDetailCtrl', ['$scope', '$routeParams', '$http',
  function($scope, $routeParams, $http) {
    $scope.layer = ""

    console.log("layerid = ", $routeParams.LayerID)
    $http.get('/layers/' + $routeParams.layerID).then(function(res) { //not sure if this works
      console.log("data: ");
      console.log(res);
  		$scope.layers = res;
  	})
    console.log("layerid = ", $routeParams.LayerID)
    $scope.LayerID = $routeParams.LayerID; //layerID casing is ok here for now
  }]);



myAppControllers.controller('AppCtrl', ['$scope', '$http', function($scope, $http) {
    $scope.layer = ""
    console.log($scope.layer + "layer");

  var refresh = function() {
    $http.get('/layers').then(function(response) {
      $scope.layers = response;
      $scope.layer = "";
    });
  }

  refresh();

/*  $scope.search = function() {
    console.log($scope.layer);
    $http.get('/layers').then(function(res) {
      console.log("res:");
      console.log(res);
      $scope.layers = res; 
    });
    
  }
*/
  $scope.addLayer = function() {
    console.log($scope.layer);
    $http.post('/addLayer', $scope.layer).then(function(res) {
      console.log("$scope.layer:")
      console.log($scope.layer);
      $scope.layers = res;
    });
    refresh();
    
  }

  //TODO: not sure what download should actually do. This won't be implemented for a while because it is not
  //currently implemented in the back-end
  $scope.download = function () {
    console.log("hi from download");
  }

  $scope.editLayer = function (id) {
    console.log(id);
    $http.get('/editLayer/' + id).then(function(res) {
      console.log($scope.layer);
      $scope.layer = res;
      console.log($scope.layer);
    });
  }

  $scope.updateLayer = function() {
    $http.put('/updateLayer/' + $scope.layer.LayerID, $scope.layer)
    refresh();
  };

/*  $scope.updateLayer = function (id) {
    console.log(id);
    $http.get('/editLayer/' + id).then(function(res) {
      $scope.layer = res;
    });
  }*/


}]);