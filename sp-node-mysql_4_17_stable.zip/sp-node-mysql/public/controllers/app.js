/*
var phonecatApp = angular.module('phonecatApp', [
  'ngRoute',
  'phonecatControllers'
]);
*/
var myApp = angular.module('myApp', [
  'ngRoute',
  'myAppControllers'
]);

myApp.config(['$routeProvider',
  function($routeProvider) {
        $routeProvider.
      when('/layers/', {
        templateUrl: 'layerlist_view.html',
        controller: 'AppCtrl'
      }).
      when('/layers/:LayerID', {
        templateUrl: 'layer_view.html',
        controller: 'LayerDetailCtrl'
      }).
      otherwise({
        redirectTo: '/layers/'
      });
}]);