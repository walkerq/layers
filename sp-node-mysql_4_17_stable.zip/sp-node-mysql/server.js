var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mysql = require("mysql");

app.use(express.static(__dirname + "/public"));
app.use(bodyParser.json());

// First you need to create a connection to the db
var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "sesame",
  database: "layers_project"
});

con.connect(function(err){
  if(err){
    console.log('Error connecting to Db');
    return;
  }
  console.log('Connection established'); 
});

/*var input_Username = 'test1';
var input_Password = 'Example1';
var input_FirstName = 'Example1';
var input_LastName = 'Example1';
var input_DOB= '1992-8-07';
var input_UserID= 6;

var insertUser = false; //these are supposed to be collecting user input
//check triggers and consider what data validation is necessary
//test user input against those SQL triggers
var updateUserUsername = false;
var updateUserPassword = false;
var updateUserFirstName = false;
var updateUserLastName = false;
var updateUserDOB = false;
var deleteUser = false;
*/
app.get('/layers/', function (req, res) {
	console.log("received a get request!")

	con.query(
	  	'SELECT * FROM layer a ',
	  function(err,rows){
	    if(err) throw err;
	    res.json(rows);
	  }
	)
});

app.post('/addLayer', function (req, res) {
	console.log("req body data")
	console.log(req.body.data);
	console.log("req body data 0 layername")
	console.log(req.body.data[0].LayerName)
	con.query(
	  	'CALL insert_layer(?,?,?,?)',
	  	[req.body.data[0].LayerName,req.body.data[0].Length_of_Layer, req.body.data[0].FileLayer, req.body.data[0].Username],
	  function(err,rows){
	    if(err) throw err;
	    console.log(req.body.LayerName + 'added to the DB\n');
	  })
});

app.get('/editLayer/:id', function(req, res) {
	var id = req.params.id;
	console.log(id);
	con.query(
	  	'SELECT * FROM layer WHERE layerID = ' + id + ";",
	  function(err,rows){
	    if(err) throw err;
	    res.json(rows);
	  }
	)

});

app.get('/layers/:id', function(req, res) {
		console.log(req.params.id);
	//console.log(id);
	  con.query(
	  	'SELECT * FROM layer l JOIN hashtag_layer hl ON l.LayerID = hl.LayerID JOIN layer_junction lj ON l.LayerID = lj.BaseLayerID WHERE l.LayerID = 2',
	  function(err,rows){
	    if(err) throw err;
	    res.json(rows);
	  }
	)
	

});

//TODO: right now you can only update layer name. I don't feel like adding the other options
//since we will probably want to change how this works later to make it more SQL and less JS
app.put('/updateLayer/:id', function (req, res) {
	con.query(
	  'CALL update_layer_name(?, ?)',
	  [req.body.data[0].LayerName, req.body.data[0].LayerID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('Layer name changed'); //we can only update name at the moment...also need to implement refresh
	    console.log(rows);
	  }
	)
	//TODO: somehow update the particular layer; probably existing SQL query
});

/*//Insert a User
if (insertUser == true) {
	con.query(
	  'CALL insert_user(?, ?, ?, ?, ?)',
	  [input_Username,input_Password, input_FirstName, input_LastName, input_DOB],
	  function(err,rows){
	    if(err) throw err;
	    console.log('User inserted into Db\n');
	    console.log(rows);
	  }
	)
};

//Update a User Username
if (updateUserUsername == true) {
	con.query(
	  'CALL update_user_username(?, ?)',
	  [input_Username,input_UserID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('Username updated in Db\n');
	    console.log(rows);
	  }
	)
};

//Update a User Password
if (updateUserPassword == true) {
	con.query(
	  'CALL update_user_password(?, ?)',
	  [input_Password,input_UserID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('User Password updated in Db\n');
	    console.log(rows);
	  }
	)
};

//Update a User First Name
if (updateUserFirstName == true) {
	con.query(
	  'CALL update_user_first_name(?, ?)',
	  [input_FirstName,input_UserID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('User First Name updated in Db\n');
	    console.log(rows);
	  }
	)
};

//Update a User Last Name
if (updateUserLastName == true) {
	con.query(
	  'CALL update_user_last_name(?, ?)',
	  [input_LastName,input_UserID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('User Last Name updated in Db\n');
	    console.log(rows);
	  }
	)
};

//Update a User DOB
if (updateUserDOB == true) {
	con.query(
	  'CALL update_user_dob(?, ?)',
	  [input_DOB,input_UserID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('User DOB updated in Db\n');
	    console.log(rows);
	  }
	)
};

//Delete a User
if (deleteUser == true) {
	con.query(
	  'CALL delete_user(?)',
	  [input_UserID],
	  function(err,rows){
	    if(err) throw err;
	    console.log('User deleted in Db\n');
	    console.log(rows);
	  }
	)
};*/

app.listen(3000);
console.log("Server running on port 3000");